/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

/**
 *
 * @author Himashi
 */
public class Employee {
    int ID;
    String Name;
    String NIC;
    String Contact_Number;
    String Address;
    String Email;

    public Employee(int ID, String Name, String NIC, String Contact_Number, String Address, String Email) {
        this.ID = ID;
        this.Name = Name;
        this.NIC = NIC;
        this.Contact_Number = Contact_Number;
        this.Address = Address;
        this.Email = Email;
    }
    
    public Employee(){}

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getNIC() {
        return NIC;
    }

    public void setNIC(String NIC) {
        this.NIC = NIC;
    }

    public String getContact_Number() {
        return Contact_Number;
    }

    public void setContact_Number(String Contact_Number) {
        this.Contact_Number = Contact_Number;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
    
    
}
