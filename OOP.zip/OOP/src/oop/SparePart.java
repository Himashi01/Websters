/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

import java.sql.Date;

/**
 *
 * @author Himashi
 */
public class SparePart {
    int ID;
    String Part_Name;
    String Description;
    double Expense;
    Date date;
    int count;
    
    public SparePart(int ID, String Part_Name, String Description,double Expense, Date date, int count) {
       this.ID = ID;
       this.Part_Name = Part_Name;
       this.Description = Description;
       this.Expense = Expense;
       this.date = date;
       this.count = count;
        
    }
    
    public int getcount() {
        return count;
    }
    
    public void setcount(int count){
        this.count = count;
    }
    
    public Date getdate(){
        return date;
    }
    
    public void setdate(Date date){
        this.date = date;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getPart_Name() {
        return Part_Name;
    }

    public void setPart_Name(String Part_Name) {
        this.Part_Name = Part_Name;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }
    
    public double getExpense() {
        return Expense;
    }
    
    public void setExpense(double Expense) {
        this.Expense = Expense;
    }
}
