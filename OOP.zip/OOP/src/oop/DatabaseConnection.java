/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Himashi
 */
public class DatabaseConnection {

    Connection connection = null;
    PreparedStatement preparedStatement;

    // db parameters
    String sql = "SELECT booked_date FROM booking_data";

    String userName = "root";
    String localPassword = "root";

    String url = "jdbc:mysql://localhost:3306/OOP";
    // String url = "jdbc:sqlserver://LAPTOP-8K9Q95HH;instanceName=SQLEXPRESS;DatabaseName=OOP;";

    public String registerUser(String name, String nic, String contact_number, String address, String email) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            preparedStatement = connection.prepareStatement("insert into employee values (default,?,?,?,?,?)");
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, nic);
            preparedStatement.setString(3, contact_number);
            preparedStatement.setString(4, address);
            preparedStatement.setString(5, email);
            preparedStatement.executeUpdate();

        } else {
            JOptionPane.showMessageDialog(null, "fail");
        }
        connection.close();
        return null;
    }

    public void addSpareParts(String name, String description, double expenses, Date date, int count) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            preparedStatement = connection.prepareStatement("insert into spare_parts values (default,?,?,?,?,?)");
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, description);
            preparedStatement.setDouble(3, expenses);
            preparedStatement.setDate(4, date);
            preparedStatement.setInt(5, count);
            preparedStatement.executeUpdate();

            preparedStatement = connection.prepareStatement("insert into report values (default,?,?,?,?)");
            preparedStatement.setString(1, description);
            preparedStatement.setDouble(2, 0.0);
            preparedStatement.setDouble(3, expenses);
            preparedStatement.setDate(4, date);
            preparedStatement.executeUpdate();

        } else {
            JOptionPane.showMessageDialog(null, "database connection fail");

        }
        connection.close();
    }

    public void updateSpareParts(SparePart sparepart) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            preparedStatement = connection.prepareStatement("update spare_parts set Part_Name=?,Description=?,Expense=?,date=?, count = ? where ID=?");
            preparedStatement.setString(1, sparepart.getPart_Name());
            preparedStatement.setString(2, sparepart.getDescription());
            preparedStatement.setDouble(3, sparepart.getExpense());
            preparedStatement.setDate(4, sparepart.getdate());
            preparedStatement.setInt(6, sparepart.getID());
            preparedStatement.setInt(5, sparepart.getcount());
            preparedStatement.executeUpdate();

        } else {
            JOptionPane.showMessageDialog(null, "database connection fail");

        }
        connection.close();
    }

    void addRepairJob(String name, String plate_number, String customer_nic, String customer_name, String employee, double payment, java.sql.Date date, String status,int sparePartID, int numOfParts) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            preparedStatement = connection.prepareStatement("insert into repair_jobs values (default,?,?,?,?,?,?,?,?,?,?)");
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, plate_number);
            preparedStatement.setString(3, customer_nic);
            preparedStatement.setString(4, customer_name);
            preparedStatement.setString(5, employee);
            preparedStatement.setDouble(6, payment);
            preparedStatement.setDate(7, date);
            preparedStatement.setString(8, status);
            preparedStatement.setInt(9, sparePartID);
            preparedStatement.setInt(10, numOfParts);
            preparedStatement.executeUpdate();

            preparedStatement = connection.prepareStatement("insert into report values (default,?,?,?,?)");
            preparedStatement.setString(1, "repair job on vehicle " + plate_number);
            preparedStatement.setDouble(2, payment);
            preparedStatement.setDouble(3, 0.0);
            preparedStatement.setDate(4, date);
            preparedStatement.executeUpdate();
        }
    }

    void addRestorationJob(String name, String plate_number, String customer_nic, String customer_name, String employee, double payment, Date date,String status) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            preparedStatement = connection.prepareStatement("insert into restoration_jobs values (default,?,?,?,?,?,?,?,?)");
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, plate_number);
            preparedStatement.setString(3, customer_nic);
            preparedStatement.setString(4, customer_name);
            preparedStatement.setString(5, employee);
            preparedStatement.setDouble(6, payment);
            preparedStatement.setDate(7, date);
            preparedStatement.setString(8, status);
            preparedStatement.executeUpdate();

            preparedStatement = connection.prepareStatement("insert into report values (default,?,?,?,?)");
            preparedStatement.setString(1, "restoration job on vehicle " + plate_number);
            preparedStatement.setDouble(2, payment);
            preparedStatement.setDouble(3, 0.0);
            preparedStatement.setDate(4, date);
            preparedStatement.executeUpdate();
        }
    }

    public ArrayList<RepairJob> getRepairJobs() throws ClassNotFoundException, SQLException {

        ArrayList<RepairJob> repairJobs = new ArrayList<>();
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            Statement statement;
            statement = connection.createStatement();
            String sql = ("SELECT * FROM repair_jobs;");

            ResultSet rs = statement.executeQuery(sql);
            while (rs.next()) {
                int id = rs.getInt("ID");
                String job_name = rs.getString("Job_Name");
                String vehicle_plate_number = rs.getString("Vehicle_Plate_Number");
                String customer_nic = rs.getString("Customer_NIC");
                String customer_name = rs.getString("Customer_Name");
                String employee = rs.getString("Employee");
                double payment = rs.getDouble("Payment");
                Date date = rs.getDate("date");
                String status = rs.getString("Status");
                int sparePartId = rs.getInt("Spare_Part_ID");
                int spareCount = rs.getInt("No_Of_Parts");
                        

                RepairJob repairJob = new RepairJob(id, job_name, vehicle_plate_number, customer_nic, customer_name, employee, payment, date, status,sparePartId, spareCount);
                repairJobs.add(repairJob);

            }
            connection.close();

        }

        return repairJobs;
    }

    public ArrayList<Report> getReport(String month) throws ClassNotFoundException, SQLException {

        ArrayList<Report> reports = new ArrayList<>();
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
          
            String sql = ("SELECT * FROM report where month(date)=?");

             PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,(month));

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String description = rs.getString("Description");
                double income = rs.getDouble("Income");
                double expenses = rs.getDouble("Expenses");
                Date date = rs.getDate("date");

                Report report = new Report(id, description, income, expenses, date);
                reports.add(report);

            }
            connection.close();

        }

        return reports;

    }

    public ArrayList<RestorationJob> getRestorationJobs() throws ClassNotFoundException, SQLException {

        ArrayList<RestorationJob> restorationJobs = new ArrayList<>();
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            Statement statement;
            statement = connection.createStatement();
            String sql = ("SELECT * FROM restoration_jobs;");

            ResultSet rs = statement.executeQuery(sql);
            while (rs.next()) {
                int id = rs.getInt("ID");
                String resJob_name = rs.getString("resJob_Name");
                String vehicle_plate_number = rs.getString("Vehicle_Plate_Number");
                String customer_nic = rs.getString("Customer_NIC");
                String customer_name = rs.getString("Customer_Name");
                String employee = rs.getString("Employee");
                double payment = rs.getDouble("Payment");
                Date date = rs.getDate("date");
                String status = rs.getString("Status");

                RestorationJob restorationJob = new RestorationJob(id, resJob_name, vehicle_plate_number, customer_nic, customer_name, employee, payment, date, status);
                restorationJobs.add(restorationJob);
            }

            connection.close();
        }

        return restorationJobs;
    }

    public ArrayList<SparePart> getSpareParts() throws ClassNotFoundException, SQLException {

        ArrayList<SparePart> spareParts = new ArrayList<>();
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            Statement statement;
            statement = connection.createStatement();
            String sql = ("SELECT * FROM spare_parts;");

            ResultSet rs = statement.executeQuery(sql);
            while (rs.next()) {
                int id = rs.getInt("ID");
                String part_name = rs.getString("Part_Name");
                String description = rs.getString("Description");
                Date date = rs.getDate("date");
                double expense = rs.getDouble("Expense");
                int count = rs.getInt("count");

                SparePart sparePart = new SparePart(id, part_name, description, expense, date, count);
                spareParts.add(sparePart);
            }

            connection.close();
        }
        return spareParts;
    }

    public ArrayList<Employee> getEmployees() throws ClassNotFoundException, SQLException {

        ArrayList<Employee> employees = new ArrayList<>();
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            Statement statement;
            statement = connection.createStatement();
            String sql = ("SELECT * FROM employee;");

            ResultSet rs = statement.executeQuery(sql);
            while (rs.next()) {
                int id = rs.getInt("ID");
                String name = rs.getString("Name");
                String nic = rs.getString("NIC");
                String contact_number = rs.getString("Contact_number");
                String address = rs.getString("Address");
                String email = rs.getString("Email");

                Employee employee = new Employee(id, name, nic, contact_number, address, email);
                employees.add(employee);
            }

            connection.close();
        }

        return employees;
    }

    public Employee getEmployee(String employeeId) throws ClassNotFoundException, SQLException {

        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {

            String sql = ("SELECT * FROM oop.employee where ID = ?");
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(employeeId));

            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {

                int id = rs.getInt("ID");

                String name = rs.getString("Name");
                String nic = rs.getString("NIC");
                String contact_number = rs.getString("Contact_number");
                String address = rs.getString("Address");
                String email = rs.getString("Email");

                Employee employee = new Employee(id, name, nic, contact_number, address, email);
                return employee;
            }
        }

        return null;
    }

    public RepairJob getRepairJob(String repairJobID) throws ClassNotFoundException, SQLException {

        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {

            String sql = ("SELECT * FROM oop.repair_jobs where ID = ?");
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(repairJobID));

            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {

                int id = rs.getInt("ID");

                String name = rs.getString("Job_Name");
                String vehicle_plate_number = rs.getString("Vehicle_Plate_Number");
                String customer_nic = rs.getString("Customer_NIC");
                String customer_name = rs.getString("Customer_Name");
                String employee = rs.getString("Employee");
                double payment = rs.getDouble("Payment");
                Date date = rs.getDate("date");
                String status = rs.getString("Status");
                int sparePartId = rs.getInt("Spare_Part_ID");
                int spareCount = rs.getInt("No_Of_Parts");

                RepairJob repairJob = new RepairJob(id, name, vehicle_plate_number, customer_nic, customer_name, employee, payment, date, status,sparePartId,spareCount);
                return repairJob;
            }
        }
        return null;
    }

    public RestorationJob getRestorationJob(String restorationJobID) throws ClassNotFoundException, SQLException {

        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {

            String sql = ("SELECT * FROM oop.restoration_jobs where ID = ?");
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(restorationJobID));

            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {

                int id = rs.getInt("ID");

                String name = rs.getString("resJob_Name");
                String vehicle_plate_number = rs.getString("Vehicle_Plate_Number");
                String customer_nic = rs.getString("Customer_NIC");
                String customer_name = rs.getString("Customer_Name");
                String employee = rs.getString("Employee");
                double payment = rs.getDouble("Payment");
                Date date = rs.getDate("date");
                String status = rs.getString("Status");

                RestorationJob restorationJob = new RestorationJob(id, name, vehicle_plate_number, customer_nic, customer_name, employee, payment, date, status);
                return restorationJob;
            }
        }
        return null;
    }

    public SparePart getSparePart(String sparePartID) throws ClassNotFoundException, SQLException {

        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {

            String sql = ("SELECT * FROM oop.spare_parts where ID = ?");
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, Integer.parseInt(sparePartID));

            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {

                int id = rs.getInt("ID");

                String name = rs.getString("Part_Name");
                String description = rs.getString("Description");
                double expense = rs.getDouble("Expense");
                Date date = rs.getDate("date");
                int count = rs.getInt("count");

                SparePart sparePart = new SparePart(id, name, description, expense, date, count);
                return sparePart;
            }
        }
        return null;
    }

    public void updateEmployee(Employee employee) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            preparedStatement = connection.prepareStatement("UPDATE employee SET Name = ?,NIC = ?,Contact_Number = ?, Address = ?, Email = ? WHERE id = ?");
            preparedStatement.setString(1, employee.getName());
            preparedStatement.setString(2, employee.getNIC());
            preparedStatement.setString(3, employee.getContact_Number());
            preparedStatement.setString(4, employee.getAddress());
            preparedStatement.setString(5, employee.getEmail());
            preparedStatement.setInt(6, employee.getID());
            preparedStatement.executeUpdate();

        } else {
            JOptionPane.showMessageDialog(null, "fail");
        }
        connection.close();
    }

    public void updateRepairJob(RepairJob repairJob) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            preparedStatement = connection.prepareStatement("UPDATE repair_jobs SET Job_Name = ?, Vehicle_Plate_Number = ?, Customer_NIC = ?, Customer_Name = ?, Employee = ?, Payment = ?, date = ?, Status=?, Spare_Part_ID =?, No_Of_Parts = ? WHERE id = ?");
            preparedStatement.setString(1, repairJob.getJob_Name());
            preparedStatement.setString(2, repairJob.getVehicle_Plate_Number());
            preparedStatement.setString(3, repairJob.getCustomer_NIC());
            preparedStatement.setString(4, repairJob.getCustomer_Name());
            preparedStatement.setString(5, repairJob.getEmployee());
            preparedStatement.setDouble(6, repairJob.getPayment());
            preparedStatement.setDate(7, repairJob.getDate());
            preparedStatement.setString(8, repairJob.getStatus());
            preparedStatement.setInt(9, repairJob.getSpare_Part_ID());
            preparedStatement.setInt(10, repairJob.getNo_Of_Parts());
            preparedStatement.setInt(11, repairJob.getID());
            preparedStatement.executeUpdate();

        } else {
            JOptionPane.showMessageDialog(null, "fail");
        }
        connection.close();
    }

    public void updateRestorationJob(RestorationJob restorationJob) throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);

        if (connection != null) {
            preparedStatement = connection.prepareStatement("UPDATE restoration_jobs SET resJob_Name = ?, Vehicle_Plate_Number = ?, Customer_NIC = ?, Customer_Name = ?, Employee = ?, Payment = ?, date = ?, Status=? WHERE id = ?");
            preparedStatement.setString(1, restorationJob.getResJob_Name());
            preparedStatement.setString(2, restorationJob.getVehicle_Plate_Number());
            preparedStatement.setString(3, restorationJob.getCustomer_NIC());
            preparedStatement.setString(4, restorationJob.getCustomer_Name());
            preparedStatement.setString(5, restorationJob.getEmployee());
            preparedStatement.setDouble(6, restorationJob.getPayment());
            preparedStatement.setDate(7, restorationJob.getdate());
            preparedStatement.setString(8, restorationJob.getStatus());
            preparedStatement.setInt(9, restorationJob.getID());
            preparedStatement.executeUpdate();

        } else {
            JOptionPane.showMessageDialog(null, "fail");
        }
        connection.close();

    }

    public void deleteRepairJob(RepairJob repairJob) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);
        if (connection != null) {
            preparedStatement = connection.prepareStatement("DELETE FROM repair_jobs where ID = ?");
            preparedStatement.setInt(1, repairJob.getID());
            preparedStatement.executeUpdate();
        }
        connection.close();
    }

    public void deleteRestorationJob(RestorationJob restorationJob) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);
        if (connection != null) {
            preparedStatement = connection.prepareStatement("DELETE FROM restoration_jobs where ID = ?");
            preparedStatement.setInt(1, restorationJob.getID());
            preparedStatement.executeUpdate();
        }
        connection.close();
    }

    public void deleteSpareParts(SparePart sparePart) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);
        if (connection != null) {
            preparedStatement = connection.prepareStatement("DELETE FROM spare_parts where ID = ?");
            preparedStatement.setInt(1, sparePart.getID());
            preparedStatement.executeUpdate();
        }
        connection.close();
    }

    public void deleteEmployee(Employee employee) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, userName, localPassword);
        if (connection != null) {
            preparedStatement = connection.prepareStatement("DELETE FROM employee where ID = ?");
            preparedStatement.setInt(1, employee.getID());
            preparedStatement.executeUpdate();
        }
        connection.close();
    }
    
    
}
