/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.JOptionPane;


/**
 *
 * @author Himashi
 */
public class MainPage extends javax.swing.JFrame {

    /**
     * Creates new form MainPage
     */
    public MainPage() throws ClassNotFoundException, SQLException {
        initComponents();
        populateTable();
        populateResJobTable();
        populateSparePartTable();
        populateEmployeeTable();
        populateReportTable();
    }
    
    public void populateReportTable() throws ClassNotFoundException, SQLException{
         Date date = new Date();
         LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
         int month = localDate.getMonthValue();
          
          TextFieldMonth.setText(String.valueOf(month));
          System.out.println(month);
            DefaultTableModel tableModel = (DefaultTableModel) reportsTable.getModel();
             tableModel.setRowCount(0);
          DatabaseConnection databaseConnection = new DatabaseConnection();
         
          ArrayList<Report> reports = databaseConnection.getReport(String.valueOf(month));
          Object rowData[] = new Object[4];
             for(int i = 0; i < reports.size(); i++)
        {
     
            rowData[0] = reports.get(i).getDecription();
            rowData[1] = reports.get(i).getIncome();
            rowData[2] = reports.get(i).getExpenses();
            rowData[3] = reports.get(i).getDate();

            tableModel.addRow(rowData);
        }
    }
    
    
       public void filtereReportTable() throws ClassNotFoundException, SQLException{
         String month = TextFieldMonth.getText();
          
          TextFieldMonth.setText(String.valueOf(month));
          System.out.println(month);
            DefaultTableModel tableModel = (DefaultTableModel) reportsTable.getModel();
            tableModel.setRowCount(0);
          DatabaseConnection databaseConnection = new DatabaseConnection();
         
          ArrayList<Report> reports = databaseConnection.getReport(String.valueOf(month));
          Object rowData[] = new Object[4];
             for(int i = 0; i < reports.size(); i++)
        {
     
            rowData[0] = reports.get(i).getDecription();
            rowData[1] = reports.get(i).getIncome();
            rowData[2] = reports.get(i).getExpenses();
            rowData[3] = reports.get(i).getDate();

            tableModel.addRow(rowData);
        }
    }
    
    public void populateTable() throws ClassNotFoundException, SQLException {
     
          DefaultTableModel tableModel = (DefaultTableModel) RepairJobTable.getModel();
          DatabaseConnection databaseConnection = new DatabaseConnection();
          ArrayList<RepairJob> repairJobs = databaseConnection.getRepairJobs();
          Object rowData[] = new Object[11];
             for(int i = 0; i < repairJobs.size(); i++)
        {
            rowData[0] = repairJobs.get(i).getID();
            rowData[1] = repairJobs.get(i).getJob_Name();
            rowData[2] = repairJobs.get(i).getVehicle_Plate_Number();
            rowData[3] = repairJobs.get(i).getCustomer_NIC();
            rowData[4] = repairJobs.get(i).getCustomer_Name();
            rowData[5] = repairJobs.get(i).getEmployee();
            rowData[6] = repairJobs.get(i).getPayment();
            rowData[7] = repairJobs.get(i).getDate();
            rowData[8] = repairJobs.get(i).getStatus();
            rowData[9] = repairJobs.get(i).getSpare_Part_ID();
            rowData[10] = repairJobs.get(i).getNo_Of_Parts();
            tableModel.addRow(rowData);
        }
    
    }
    
    public void populateResJobTable() throws ClassNotFoundException, SQLException {
    
          DefaultTableModel tableModel = (DefaultTableModel) ResJobTable.getModel();
          DatabaseConnection databaseConnection = new DatabaseConnection();
          ArrayList<RestorationJob> restorationJobs = databaseConnection.getRestorationJobs();
          Object rowData[] = new Object[9];
          for(int i = 0; i < restorationJobs.size(); i++) {
              
              rowData[0] = restorationJobs.get(i).getID();
              rowData[1] = restorationJobs.get(i).getResJob_Name();
              rowData[2] = restorationJobs.get(i).getVehicle_Plate_Number();
              rowData[3] = restorationJobs.get(i).getCustomer_NIC();
              rowData[4] = restorationJobs.get(i).getCustomer_Name();
              rowData[5] = restorationJobs.get(i).getEmployee();
              rowData[6] = restorationJobs.get(i).getPayment();
              rowData[7] = restorationJobs.get(i).getdate();
                rowData[8] = restorationJobs.get(i).getStatus();
              tableModel.addRow(rowData);
          }
    }
    
    public void populateSparePartTable() throws ClassNotFoundException, SQLException {
        
        DefaultTableModel tableModel = (DefaultTableModel) SparePartTable.getModel();
        DatabaseConnection databaseConnection = new DatabaseConnection();
        ArrayList<SparePart> spareParts = databaseConnection.getSpareParts();
        Object rowData[] = new Object[6];
        for(int i = 0; i < spareParts.size(); i++) {
            
            rowData[0] = spareParts.get(i).getID();
            rowData[1] = spareParts.get(i).getPart_Name();
            rowData[2] = spareParts.get(i).getDescription();
            rowData[3] = spareParts.get(i).getExpense();
            rowData[4] = spareParts.get(i).getdate();
            rowData[5] = spareParts.get(i).getcount();
            tableModel.addRow(rowData);
        }
    }
    
    public void populateEmployeeTable() throws ClassNotFoundException, SQLException {
        
        DefaultTableModel tableModel = (DefaultTableModel) EmployeeTable.getModel();
        DatabaseConnection databaseConnection = new DatabaseConnection();
        ArrayList<Employee> employees = databaseConnection.getEmployees();
        Object rowData[] = new Object[6];
        for(int i = 0; i < employees.size(); i++) {
            
            rowData[0] = employees.get(i).getID();
            rowData[1] = employees.get(i).getName();
            rowData[2] = employees.get(i).getNIC();
            rowData[3] = employees.get(i).getContact_Number();
            rowData[4] = employees.get(i).getAddress();
            rowData[5] = employees.get(i).getEmail();
            tableModel.addRow(rowData);
        }
    }
    


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        reportsTable = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel5 = new javax.swing.JLabel();
        TextFieldMonth = new javax.swing.JTextField();
        buttonFilterMonth = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        addNewJobButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        RepairJobTable = new javax.swing.JTable();
        TextFieldRepairJobID = new javax.swing.JTextField();
        buttonUpdateRepairJob = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTextPane2 = new javax.swing.JTextPane();
        jPanel3 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        ResJobTable = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        TextFieldRestorationJobID = new javax.swing.JTextField();
        buttonUpdateRestorationJob = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTextPane3 = new javax.swing.JTextPane();
        jPanel4 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        SparePartTable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        TextFieldSparePartID = new javax.swing.JTextField();
        buttonUpdateSparePart = new javax.swing.JButton();
        jScrollPane9 = new javax.swing.JScrollPane();
        jTextPane4 = new javax.swing.JTextPane();
        jPanel5 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        EmployeeTable = new javax.swing.JTable();
        textFieldEmployeeId = new javax.swing.JTextField();
        buttonUpdate = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        jTextPane5 = new javax.swing.JTextPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        reportsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Description", "Income", "Expenses", "Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane6.setViewportView(reportsTable);

        jTextPane1.setFont(new java.awt.Font("Bodoni MT Black", 0, 24)); // NOI18N
        jTextPane1.setText("R  U  S  T   R  E  P  A  I  R  ");
        jScrollPane5.setViewportView(jTextPane1);

        jLabel5.setText("Month");

        buttonFilterMonth.setText("Filter");
        buttonFilterMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonFilterMonthActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(236, 236, 236)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(TextFieldMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(buttonFilterMonth)))
                .addGap(0, 288, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(TextFieldMonth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(buttonFilterMonth)))
                .addGap(30, 30, 30)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(281, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Home", jPanel1);

        addNewJobButton.setText("New Job");
        addNewJobButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addNewJobButtonActionPerformed(evt);
            }
        });

        RepairJobTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "JobName", "VehiclePlateNumber", "Email", "Customer_Name", "Employee", "Payment", "date", "Status", "Spare Part ID", "No.of Parts"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(RepairJobTable);

        buttonUpdateRepairJob.setText("View Job");
        buttonUpdateRepairJob.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonUpdateRepairJobActionPerformed(evt);
            }
        });

        jLabel2.setText("Repair Job ID");

        jTextPane2.setFont(new java.awt.Font("Bodoni MT Black", 0, 24)); // NOI18N
        jTextPane2.setText("R  U  S  T   R  E  P  A  I  R  ");
        jScrollPane7.setViewportView(jTextPane2);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(36, 36, 36)
                                .addComponent(TextFieldRepairJobID, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(buttonUpdateRepairJob))
                            .addComponent(addNewJobButton)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(242, 242, 242)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(282, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57)
                .addComponent(addNewJobButton)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buttonUpdateRepairJob)
                    .addComponent(TextFieldRepairJobID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(190, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Repair Jobs", jPanel2);

        jButton3.setText("New Job");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        ResJobTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "resJobName", "VehiclePlateNumber", "Email", "CustomerName", "Employee", "Payment", "date", "Status"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(ResJobTable);

        jLabel3.setText("Restoration Job ID");

        buttonUpdateRestorationJob.setText("View Restoration Job");
        buttonUpdateRestorationJob.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonUpdateRestorationJobActionPerformed(evt);
            }
        });

        jTextPane3.setFont(new java.awt.Font("Bodoni MT Black", 0, 24)); // NOI18N
        jTextPane3.setText("R  U  S  T   R  E  P  A  I  R  ");
        jScrollPane8.setViewportView(jTextPane3);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 818, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(38, 38, 38)
                                .addComponent(TextFieldRestorationJobID, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(buttonUpdateRestorationJob))
                            .addComponent(jButton3)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(243, 243, 243)
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(55, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jButton3)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(TextFieldRestorationJobID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonUpdateRestorationJob))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(212, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Restoration Jobs", jPanel3);

        jButton2.setText("Add Spare Parts");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        SparePartTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "PartName", "Description", "Expense", "date", "count"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(SparePartTable);

        jLabel4.setText("Spare Part ID");

        buttonUpdateSparePart.setText("View Spare Part");
        buttonUpdateSparePart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonUpdateSparePartActionPerformed(evt);
            }
        });

        jTextPane4.setFont(new java.awt.Font("Bodoni MT Black", 0, 24)); // NOI18N
        jTextPane4.setText("R  U  S  T   R  E  P  A  I  R  ");
        jScrollPane9.setViewportView(jTextPane4);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 596, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addGap(257, 257, 257)
                            .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel4Layout.createSequentialGroup()
                            .addGap(43, 43, 43)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jButton2)
                                .addGroup(jPanel4Layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addGap(18, 18, 18)
                                    .addComponent(TextFieldSparePartID, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(buttonUpdateSparePart))))))
                .addContainerGap(267, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(19, 19, 19)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(TextFieldSparePartID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonUpdateSparePart))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(214, 214, 214))
        );

        jTabbedPane1.addTab("Spare Parts", jPanel4);

        jButton1.setText("Add New Employees");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        EmployeeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "NIC", "Contact_Number", "Address", "Email"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(EmployeeTable);

        buttonUpdate.setText("View Employee");
        buttonUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonUpdateActionPerformed(evt);
            }
        });

        jLabel1.setText("Employee ID");

        jTextPane5.setFont(new java.awt.Font("Bodoni MT Black", 0, 24)); // NOI18N
        jTextPane5.setText("R  U  S  T   R  E  P  A  I  R  ");
        jScrollPane10.setViewportView(jTextPane5);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(258, 258, 258))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 647, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(27, 27, 27)
                        .addComponent(textFieldEmployeeId, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(buttonUpdate)))
                .addContainerGap(197, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(97, 97, 97)
                .addComponent(jButton1)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(textFieldEmployeeId, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonUpdate))
                .addGap(39, 39, 39)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(139, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Employees", jPanel5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(63, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 646, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.getAccessibleContext().setAccessibleName("Restoration Jobs");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonUpdateActionPerformed
        try {
            // TODO add your handling code here:
            String employeeId = textFieldEmployeeId.getText();
            DatabaseConnection databaseConnection = new DatabaseConnection();

            Employee employee = databaseConnection.getEmployee(employeeId);

            if(employee == null){
                JOptionPane.showMessageDialog(null, "Invalid user ID");
            }else{
                Register register = new Register(employee);
                register.setVisible(true);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_buttonUpdateActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Register register = new Register();
        this.setVisible(false);
        register.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void buttonUpdateSparePartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonUpdateSparePartActionPerformed
        try {
            // TODO add your handling code here:
            String sparePartID = TextFieldSparePartID.getText();
            DatabaseConnection databaseConnection = new DatabaseConnection();

            SparePart sparePart = databaseConnection.getSparePart(sparePartID);

            if(sparePart == null) {
                JOptionPane.showMessageDialog(null, "Invalid user ID");
            } else {
                AddSpareParts addSpareParts = new AddSpareParts(sparePart);
                addSpareParts.setVisible(true);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_buttonUpdateSparePartActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
        AddSpareParts addSpareParts = new AddSpareParts();
        addSpareParts.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void buttonUpdateRestorationJobActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonUpdateRestorationJobActionPerformed
        try {
            // TODO add your handling code here:
            String restorationJobID = TextFieldRestorationJobID.getText();
            DatabaseConnection databaseConnection = new DatabaseConnection();

            RestorationJob restorationJob = databaseConnection.getRestorationJob(restorationJobID);

            if(restorationJob == null) {
                JOptionPane.showMessageDialog(null, "Invalid user ID");
            } else {
                AddRestorationJob addRestorationJob = new AddRestorationJob(restorationJob);
                addRestorationJob.setVisible(true);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_buttonUpdateRestorationJobActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        AddRestorationJob addRestorationJob = new AddRestorationJob();
        addRestorationJob.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void buttonUpdateRepairJobActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonUpdateRepairJobActionPerformed
        try {
            // TODO add your handling code here:
            String repairJobID = TextFieldRepairJobID.getText();
            DatabaseConnection databaseConnection = new DatabaseConnection();

            RepairJob repairJob = databaseConnection.getRepairJob(repairJobID);

            if(repairJob == null) {
                JOptionPane.showMessageDialog(null, "Invalid user ID");
            } else {
                AddRepairJob addRepairJob = new AddRepairJob(repairJob);
                addRepairJob.setVisible(true);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_buttonUpdateRepairJobActionPerformed

    private void addNewJobButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addNewJobButtonActionPerformed
        // TODO add your handling code here:
        AddRepairJob addRepairJob = new AddRepairJob();
        addRepairJob.setVisible(true);

    }//GEN-LAST:event_addNewJobButtonActionPerformed

    private void buttonFilterMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonFilterMonthActionPerformed
        try {
            // TODO add your handling code here:
            filtereReportTable();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_buttonFilterMonthActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new MainPage().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(MainPage.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
        });
    }
    
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable EmployeeTable;
    private javax.swing.JTable RepairJobTable;
    private javax.swing.JTable ResJobTable;
    private javax.swing.JTable SparePartTable;
    private javax.swing.JTextField TextFieldMonth;
    private javax.swing.JTextField TextFieldRepairJobID;
    private javax.swing.JTextField TextFieldRestorationJobID;
    private javax.swing.JTextField TextFieldSparePartID;
    private javax.swing.JButton addNewJobButton;
    private javax.swing.JButton buttonFilterMonth;
    private javax.swing.JButton buttonUpdate;
    private javax.swing.JButton buttonUpdateRepairJob;
    private javax.swing.JButton buttonUpdateRestorationJob;
    private javax.swing.JButton buttonUpdateSparePart;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTextPane jTextPane2;
    private javax.swing.JTextPane jTextPane3;
    private javax.swing.JTextPane jTextPane4;
    private javax.swing.JTextPane jTextPane5;
    private javax.swing.JTable reportsTable;
    private javax.swing.JTextField textFieldEmployeeId;
    // End of variables declaration//GEN-END:variables
}
