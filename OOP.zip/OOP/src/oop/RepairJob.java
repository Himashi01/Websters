/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

import java.sql.Date;

/**
 *
 * @author Himashi
 */
public class RepairJob {
   int ID;
   String Job_Name;
   String Vehicle_Plate_Number;
   String Customer_NIC;
   String Customer_Name;
   String Employee;
   double Payment;
   Date date;
   String status;
   int sparePartID;
   int numOfParts;

    public RepairJob(int ID, String Job_Name, String Vehicle_Plate_Number, String Customer_NIC, String Customer_Name, String Employee, double Payment,Date date,String status, int Spare_Part_ID, int No_Of_Parts) {
        this.ID = ID;
        this.Job_Name = Job_Name;
        this.Vehicle_Plate_Number = Vehicle_Plate_Number;
        this.Customer_NIC = Customer_NIC;
        this.Customer_Name = Customer_Name;
        this.Employee = Employee;
        this.Payment = Payment;
        this.date = date;
        this.status = status;
        this.sparePartID = Spare_Part_ID;
        this.numOfParts = No_Of_Parts;
    }
    
    public RepairJob(){}
    
    public int getNo_Of_Parts() {
        return numOfParts;
    }
    
    public void setNo_Of_Parts(int No_Of_Parts){
        this.numOfParts =  No_Of_Parts;
    }
    
    public int getSpare_Part_ID() {
        return sparePartID;
    }
    
    public void setSpare_Part_ID(int Spare_Part_ID) {
        this.sparePartID = Spare_Part_ID;
    }
    
    public String getStatus(){
        return status;
    }
    
    public void setStatus(String status){
        this.status = status;
    }
   
   public Date getDate(){
       return date;
   }
   
   public void setDAte(Date date){
       this.date = date;
   }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getJob_Name() {
        return Job_Name;
    }

    public void setJob_Name(String Job_Name) {
        this.Job_Name = Job_Name;
    }

    public String getVehicle_Plate_Number() {
        return Vehicle_Plate_Number;
    }

    public void setVehicle_Plate_Number(String Vehicle_Plate_Number) {
        this.Vehicle_Plate_Number = Vehicle_Plate_Number;
    }

    public String getCustomer_NIC() {
        return Customer_NIC;
    }

    public void setCustomer_NIC(String Customer_NIC) {
        this.Customer_NIC = Customer_NIC;
    }

    public String getCustomer_Name() {
        return Customer_Name;
    }

    public void setCustomer_Name(String Customer_Name) {
        this.Customer_Name = Customer_Name;
    }

    public String getEmployee() {
        return Employee;
    }

    public void setEmployee(String Employee) {
        this.Employee = Employee;
    }
    
    public void setPayment(double Payment){
        this.Payment = Payment;
    }
    
    public double getPayment(){
        return Payment;
    }
   
   
}
