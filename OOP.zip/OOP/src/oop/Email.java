/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 *
 * @author Himashi
 */
public class Email {

    String to;
    String from;
    String host = "smtp.gmail.com";
    String jobType;
    String spare;
    
    

    final String user = "testoopbythilina@gmail.com";//change accordingly  
    final String password = "testoop1121";//change accordingly  

    public Email(String to, String jobType) {
        this.to = to;
        this.jobType = jobType;
    }
    
    public Email(){}
    
    public void setSpare(String spare){
        this.spare = spare;
    }

  
   

    public void sendMailSmtp() {
        Properties props = new Properties();
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port", "587");

        Session session = Session.getDefaultInstance(props,
                new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, password);
            }
        });

        //Compose the message  
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(user));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            System.out.println(to);

            if (jobType == "repair") {
                message.setSubject("This is a message regarding the vehicle repair.");
                message.setText("The vehicle repair has being successfully completed. You may come and collect your vehicle from our outlet.");

                //send the message  
                Transport.send(message);

                System.out.println("message sent successfully...");
            }else if (jobType == "restore") {
                 message.setSubject("This is a message regarding the vehicle restoration.");
                message.setText("The vehicle restoration has being successfully completed. You may come and collect you vehicle from our outlet.");

                //send the message  
                Transport.send(message);

                System.out.println("message sent successfully...");
            }else if (jobType == "outOfStock") {
                 message.setSubject("This is a message regarding the vehicle restoration.");
                message.setText("The vehicle restoration has being successfully completed. You may come and collect you vehicle from our outlet.");

                //send the message  
                Transport.send(message);

                System.out.println("message sent successfully...");
            }

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
    
    public void sendOutOfStockEmail(){
        Properties props = new Properties();
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port", "587");

        Session session = Session.getDefaultInstance(props,
                new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, password);
            }
        });

        //Compose the message  
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(user));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress("himashijayaweera@gmail.com"));
            System.out.println(to);

           //out of stock messsage
                message.setSubject("This is a message regarding the vehicle repair.");
                message.setText(spare + "is low quantity");

                //send the message  
                Transport.send(message);

                System.out.println("message sent successfully...");
         
              

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    
    }
}
