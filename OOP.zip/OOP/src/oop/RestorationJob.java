/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

import java.sql.Date;

/**
 *
 * @author Himashi
 */
public class RestorationJob {
    int ID;
    String resJob_Name;
    String Vehicle_Plate_Number;
    String Customer_NIC;
    String Customer_Name;
    String Employee;
    double Payment;
    Date date;
    String Status;

    public RestorationJob(int ID, String resJob_Name, String Vehicle_Plate_Number, String Customer_NIC, String Customer_Name, String Employee, double Payment, Date date, String Status) {
        this.ID = ID;
        this.resJob_Name = resJob_Name;
        this.Vehicle_Plate_Number = Vehicle_Plate_Number;
        this.Customer_NIC = Customer_NIC;
        this.Customer_Name = Customer_Name;
        this.Employee = Employee;
        this.Payment = Payment;
        this.date = date;
        this.Status = Status;
                }
    
    public String getStatus() {
        return Status;
    }
    
    public void setStatus(String status){
    
        this.Status = status;
    }
    public Date getdate(){
        return date;
    }
    
    public void setdate(Date date){
        this.date = date;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getResJob_Name() {
        return resJob_Name;
    }

    public void setResJob_Name(String resJob_Name) {
        this.resJob_Name = resJob_Name;
    }

    public String getVehicle_Plate_Number() {
        return Vehicle_Plate_Number;
    }

    public void setVehicle_Plate_Number(String Vehicle_Plate_Number) {
        this.Vehicle_Plate_Number = Vehicle_Plate_Number;
    }

    public String getCustomer_NIC() {
        return Customer_NIC;
    }

    public void setCustomer_NIC(String Customer_NIC) {
        this.Customer_NIC = Customer_NIC;
    }

    public String getCustomer_Name() {
        return Customer_Name;
    }

    public void setCustomer_Name(String Customer_Name) {
        this.Customer_Name = Customer_Name;
    }

    public String getEmployee() {
        return Employee;
    }

    public void setEmployee(String Employee) {
        this.Employee = Employee;
    }
    
    public double getPayment() {
        return Payment;
    }
    
    public void setPayment(double Payment) {
        this.Payment = Payment;
    }
    
    
}
